//>>built
define("dojox/mobile/DatePicker",["dojo/_base/lang","./_PickerChooser!DatePicker"],function(_1,_2){
return _1.setObject("dojox.mobile.DatePicker",_2);
});
