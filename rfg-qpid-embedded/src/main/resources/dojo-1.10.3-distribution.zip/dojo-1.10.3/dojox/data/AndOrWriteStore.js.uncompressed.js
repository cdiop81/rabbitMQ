define("dojox/data/AndOrWriteStore", ["dojo/_base/declare", "dojo/data/ItemFileWriteStore", "./AndOrReadStore"],
  function(declare, ItemFileWriteStore, AndOrReadStore){

// module:
//		dojox/data/AndOrWriteStore
// summary:
//		TODOC

return declare("dojox.data.AndOrWriteStore", [ItemFileWriteStore, AndOrReadStore], {});

});
