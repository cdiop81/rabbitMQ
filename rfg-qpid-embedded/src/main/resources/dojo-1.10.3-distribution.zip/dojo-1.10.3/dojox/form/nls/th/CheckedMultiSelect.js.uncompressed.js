define(
"dojox/form/nls/th/CheckedMultiSelect", ({
	invalidMessage: "อย่างน้อยหนึ่งรายการต้องถูกเลือก",
	multiSelectLabelText: "{num} รายการถูกเลือก"
})
);
