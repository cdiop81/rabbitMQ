define(
"dojox/form/nls/id/Uploader", ({
	label: "Pilih File..."
})
);

