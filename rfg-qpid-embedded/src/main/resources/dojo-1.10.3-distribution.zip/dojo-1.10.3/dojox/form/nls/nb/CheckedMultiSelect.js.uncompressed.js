define(
"dojox/form/nls/nb/CheckedMultiSelect", ({
	invalidMessage: "Du må velge minst ett element.",
	multiSelectLabelText: "{num} element(er) valgt"
})
);
