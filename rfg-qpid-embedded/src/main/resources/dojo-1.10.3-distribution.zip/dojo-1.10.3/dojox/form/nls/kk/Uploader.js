//>>built
define("dojox/form/nls/kk/Uploader",({label:"Файлдарды таңдау..."}));
