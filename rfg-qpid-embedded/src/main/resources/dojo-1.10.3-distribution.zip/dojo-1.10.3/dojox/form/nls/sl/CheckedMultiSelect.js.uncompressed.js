define(
"dojox/form/nls/sl/CheckedMultiSelect", ({
	invalidMessage: "Izbrati morate vsaj eno postavko.",
	multiSelectLabelText: "Število izbranih postavk: {num}"
})
);
