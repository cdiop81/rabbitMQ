//>>built
define("dojox/form/nls/pt-pt/PasswordValidator",({nomatchMessage:"As palavras-passe não correspondem.",badPasswordMessage:"Palavra-passe não válida."}));
