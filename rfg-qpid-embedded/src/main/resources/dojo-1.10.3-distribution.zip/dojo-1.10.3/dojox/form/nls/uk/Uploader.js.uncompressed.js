define(
"dojox/form/nls/uk/Uploader", ({
	label: "Виберіть файли..."
})
);
