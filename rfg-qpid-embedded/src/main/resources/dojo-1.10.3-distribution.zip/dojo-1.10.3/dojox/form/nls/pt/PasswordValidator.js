//>>built
define("dojox/form/nls/pt/PasswordValidator",({nomatchMessage:"As senhas não correspondem.",badPasswordMessage:"Senha Inválida."}));
