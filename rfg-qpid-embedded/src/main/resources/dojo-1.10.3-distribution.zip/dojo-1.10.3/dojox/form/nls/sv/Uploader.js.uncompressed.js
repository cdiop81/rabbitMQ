define(
"dojox/form/nls/sv/Uploader", ({
	label: "Välj filer..."
})
);
