define(
"dojox/form/nls/zh/Uploader", ({
	label: "选择文件..."
})
);
