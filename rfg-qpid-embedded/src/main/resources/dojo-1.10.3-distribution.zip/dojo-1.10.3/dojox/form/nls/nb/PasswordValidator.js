//>>built
define("dojox/form/nls/nb/PasswordValidator",({nomatchMessage:"Passordene samsvarer ikke.",badPasswordMessage:"Ugyldig passord."}));
