//>>built
define("dojox/form/nls/ko/PasswordValidator",({nomatchMessage:"비밀번호가 일치하지 않습니다.",badPasswordMessage:"올바르지 않은 비밀번호"}));
