define(
"dojox/form/nls/ru/PasswordValidator", ({
        nomatchMessage: "Пароли не совпадают.",
	badPasswordMessage: "Неправильный пароль."
})
);
