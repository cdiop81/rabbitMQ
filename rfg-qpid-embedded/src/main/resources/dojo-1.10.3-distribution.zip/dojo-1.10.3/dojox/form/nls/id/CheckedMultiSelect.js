//>>built
define("dojox/form/nls/id/CheckedMultiSelect",({invalidMessage:"Setidaknya harus dipilih satu buah item.",multiSelectLabelText:"{num} item yang dipilih"}));
