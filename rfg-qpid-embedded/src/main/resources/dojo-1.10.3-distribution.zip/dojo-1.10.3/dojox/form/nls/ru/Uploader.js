//>>built
define("dojox/form/nls/ru/Uploader",({label:"Выберите файлы..."}));
