//>>built
define("dojox/form/nls/ca/PasswordValidator",({nomatchMessage:"Les contrasenyes no coincideixen",badPasswordMessage:"La contrasenya no és correcta"}));
