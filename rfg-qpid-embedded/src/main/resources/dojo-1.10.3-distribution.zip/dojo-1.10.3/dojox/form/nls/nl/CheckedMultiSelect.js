//>>built
define("dojox/form/nls/nl/CheckedMultiSelect",({invalidMessage:"Er moet ten minste één item geselecteerd worden.",multiSelectLabelText:"{num} item(s) geselecteerd"}));
