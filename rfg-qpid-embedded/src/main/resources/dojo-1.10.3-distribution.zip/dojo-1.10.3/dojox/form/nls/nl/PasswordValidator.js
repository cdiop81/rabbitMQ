//>>built
define("dojox/form/nls/nl/PasswordValidator",({nomatchMessage:"Wachtwoorden komen niet overeen.",badPasswordMessage:"Ongeldig wachtwoord."}));
