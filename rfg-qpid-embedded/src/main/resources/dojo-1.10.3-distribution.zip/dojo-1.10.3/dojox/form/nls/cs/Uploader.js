//>>built
define("dojox/form/nls/cs/Uploader",({label:"Vybrat soubory..."}));
