//>>built
define("dojox/form/DropDownStack",["dijit/form/Select","./_SelectStackMixin","dojo/_base/declare"],function(_1,_2,_3){
return _3("dojox.form.DropDownStack",[_1,_2]);
});
