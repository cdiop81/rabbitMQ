//>>built
define("dojox/form/nls/fr/Uploader",({label:"Sélectionner les fichiers..."}));
