define(
"dojox/form/nls/el/CheckedMultiSelect", ({
	invalidMessage: "Πρέπει να επιλέξετε τουλάχιστον ένα στοιχείο.",
	multiSelectLabelText: "Επιλέχθηκε(-αν) {num} στοιχείο(-α)"
})
);
