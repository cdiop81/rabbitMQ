define(
"dojox/form/nls/ja/PasswordValidator", ({
        nomatchMessage: "パスワードが一致しません。",
	badPasswordMessage: "無効なパスワードです。"
})
);
