define(
"dojox/form/nls/kk/PasswordValidator", ({
        nomatchMessage: "Құпия сөздер сәйкес емес.",
	badPasswordMessage: "Құпия сөз дұрыс емес."
})
);
