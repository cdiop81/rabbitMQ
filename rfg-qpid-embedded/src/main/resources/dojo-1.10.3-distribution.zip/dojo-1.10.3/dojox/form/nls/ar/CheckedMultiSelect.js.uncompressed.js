define(
"dojox/form/nls/ar/CheckedMultiSelect", ({
	invalidMessage: "يجب تحديد بند واحد على الأقل. ",
	multiSelectLabelText: "تم تحديد {num} بند/بنود"
})
);
