define(
"dojox/form/nls/hr/PasswordValidator", ({
        nomatchMessage: "Lozinke se ne podudaraju.",
	badPasswordMessage: "Neispravna lozinka."
})
);
