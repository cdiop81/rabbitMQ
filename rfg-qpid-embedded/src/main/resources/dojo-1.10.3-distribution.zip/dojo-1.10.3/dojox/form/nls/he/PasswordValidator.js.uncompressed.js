define(
"dojox/form/nls/he/PasswordValidator", ({
        nomatchMessage: "הסיסמאות אינן זהות.",
	badPasswordMessage: "סיסמה לא חוקית."
})
);
