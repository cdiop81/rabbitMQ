//>>built
define("dojox/form/nls/hr/CheckedMultiSelect",({invalidMessage:"Mora biti izabrana najmanje jedna stavka.",multiSelectLabelText:"{num} stavki je izabrano"}));
