define(
"dojox/form/nls/de/PasswordValidator", ({
        nomatchMessage: "Die Kennwörter stimmen nicht überein.",
	badPasswordMessage: "Ungültiges Kennwort."
})
);
