define(
"dojox/form/nls/nb/Uploader", ({
	label: "Velg filer..."
})
);
