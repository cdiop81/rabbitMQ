//>>built
define("dojox/form/nls/ro/Uploader",({label:"Selectare fişiere..."}));
