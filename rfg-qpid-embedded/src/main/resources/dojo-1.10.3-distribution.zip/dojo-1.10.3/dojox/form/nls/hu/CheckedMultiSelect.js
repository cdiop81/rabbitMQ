//>>built
define("dojox/form/nls/hu/CheckedMultiSelect",({invalidMessage:"Legalább egy tételt ki kell választani.",multiSelectLabelText:"{num} elem van kiválasztva"}));
