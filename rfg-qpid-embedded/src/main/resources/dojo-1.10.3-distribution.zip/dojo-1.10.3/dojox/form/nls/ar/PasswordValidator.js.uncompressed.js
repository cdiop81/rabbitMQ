define(
"dojox/form/nls/ar/PasswordValidator", ({
        nomatchMessage: "كلمات السرية غير مطابقة.",
	badPasswordMessage: "كلمة سرية غير صحيحة."
})
);
