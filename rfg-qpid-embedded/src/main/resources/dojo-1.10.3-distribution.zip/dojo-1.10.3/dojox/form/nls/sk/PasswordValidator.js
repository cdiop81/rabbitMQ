//>>built
define("dojox/form/nls/sk/PasswordValidator",({nomatchMessage:"Heslá sa nezhodujú.",badPasswordMessage:"Neplatné heslo."}));
