define(
"dojox/form/nls/tr/PasswordValidator", ({
        nomatchMessage: "Parolalar eşleşmiyor.",
	badPasswordMessage: "Geçersiz Parola."
})
);
