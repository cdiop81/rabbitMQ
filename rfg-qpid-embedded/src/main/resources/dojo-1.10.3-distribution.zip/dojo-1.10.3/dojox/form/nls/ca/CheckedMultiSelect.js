//>>built
define("dojox/form/nls/ca/CheckedMultiSelect",({invalidMessage:"Cal seleccionar, com a mínim, un element.",multiSelectLabelText:"{num} element(s) seleccionat(s)"}));
