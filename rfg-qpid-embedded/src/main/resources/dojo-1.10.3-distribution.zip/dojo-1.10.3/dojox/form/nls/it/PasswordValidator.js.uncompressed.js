define(
"dojox/form/nls/it/PasswordValidator", ({
        nomatchMessage: "Le password non corrispondono.",
	badPasswordMessage: "Password non valida."
})
);
