//>>built
define("dojox/form/nls/da/CheckedMultiSelect",({invalidMessage:"Du skal vælge mindst ét element.",multiSelectLabelText:"{num} element(er) valgt"}));
