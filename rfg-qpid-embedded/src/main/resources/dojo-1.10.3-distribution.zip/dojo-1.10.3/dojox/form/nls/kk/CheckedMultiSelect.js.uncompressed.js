define(
"dojox/form/nls/kk/CheckedMultiSelect", ({
	invalidMessage: "Кемінде бір элемент таңдалуы керек.",
	multiSelectLabelText: "{num} элемент(тер)і таңдалды"
})
);
