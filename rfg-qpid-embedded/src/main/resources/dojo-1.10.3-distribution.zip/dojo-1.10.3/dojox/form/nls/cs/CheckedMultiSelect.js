//>>built
define("dojox/form/nls/cs/CheckedMultiSelect",({invalidMessage:"Je třeba vybrat alespoň jednu položku.",multiSelectLabelText:"Počet vybraných položek: {num}"}));
