define(
"dojox/form/nls/ro/PasswordValidator", ({
        nomatchMessage: "Parolele nu se potrivesc.",
	badPasswordMessage: "Parolă invalidă."
})
);
