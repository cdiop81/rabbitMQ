define(
"dojox/form/nls/pl/Uploader", ({
	label: "Wybierz pliki..."
})
);
