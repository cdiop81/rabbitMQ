//>>built
define("dojox/form/nls/sl/Uploader",({label:"Izberi datoteke ..."}));
