//>>built
define("dojox/form/nls/it/Uploader",({label:"Seleziona file..."}));
