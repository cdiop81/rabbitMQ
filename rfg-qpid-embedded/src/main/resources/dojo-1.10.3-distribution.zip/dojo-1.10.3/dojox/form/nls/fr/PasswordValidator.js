//>>built
define("dojox/form/nls/fr/PasswordValidator",({nomatchMessage:"Les mots de passe ne correspondent pas.",badPasswordMessage:"Mot de passe incorrect."}));
