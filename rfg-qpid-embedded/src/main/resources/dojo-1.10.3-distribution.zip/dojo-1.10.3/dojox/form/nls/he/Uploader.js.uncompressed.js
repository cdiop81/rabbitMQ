define(
"dojox/form/nls/he/Uploader", ({
	label: "בחירת קבצים...‏"
})
);
