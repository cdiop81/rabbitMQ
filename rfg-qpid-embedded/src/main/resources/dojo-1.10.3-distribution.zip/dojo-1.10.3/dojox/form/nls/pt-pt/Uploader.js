//>>built
define("dojox/form/nls/pt-pt/Uploader",({label:"Seleccionar ficheiros..."}));
