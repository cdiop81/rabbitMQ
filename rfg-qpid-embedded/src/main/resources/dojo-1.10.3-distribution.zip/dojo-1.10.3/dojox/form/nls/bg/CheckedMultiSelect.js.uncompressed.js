define(
"dojox/form/nls/bg/CheckedMultiSelect", ({
	invalidMessage: "Трябва да бъде избран поне един елемент.",
	multiSelectLabelText: "избран/и {num} елемент/и"
})
);
