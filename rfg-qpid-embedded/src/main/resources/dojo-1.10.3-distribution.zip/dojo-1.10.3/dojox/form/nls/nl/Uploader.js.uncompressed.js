define(
"dojox/form/nls/nl/Uploader", ({
	label: "Bestanden selecteren..."
})
);
