define(
"dojox/form/nls/sk/CheckedMultiSelect", ({
	invalidMessage: "Musíte vybrať aspoň jednu položku.",
	multiSelectLabelText: "Vybraté položky: {num}"
})
);
