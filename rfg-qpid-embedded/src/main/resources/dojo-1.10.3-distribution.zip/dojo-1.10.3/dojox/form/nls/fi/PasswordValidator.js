//>>built
define("dojox/form/nls/fi/PasswordValidator",({nomatchMessage:"Salasanat eivät täsmää.",badPasswordMessage:"Salasana ei kelpaa."}));
