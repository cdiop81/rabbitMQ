//>>built
define("dojox/form/_HasDropDown",["dojo/_base/kernel","dojo/_base/lang","dijit/_HasDropDown"],function(_1,_2){
_1.deprecated("dojox.form._HasDropDown","Use dijit._HasDropDown instead","2.0");
lang.setObject("dojox.form._HasDropDown",_2);
return _2;
});
