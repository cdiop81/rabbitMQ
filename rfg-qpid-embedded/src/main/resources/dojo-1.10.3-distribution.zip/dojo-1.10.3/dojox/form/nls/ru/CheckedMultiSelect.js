//>>built
define("dojox/form/nls/ru/CheckedMultiSelect",({invalidMessage:"Выберите хотя бы один элемент.",multiSelectLabelText:"Выбрано: {num}"}));
