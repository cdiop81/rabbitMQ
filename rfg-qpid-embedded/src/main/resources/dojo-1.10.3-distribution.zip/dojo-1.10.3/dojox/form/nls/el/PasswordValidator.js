//>>built
define("dojox/form/nls/el/PasswordValidator",({nomatchMessage:"Οι κωδικοί πρόσβασης δεν συμφωνούν.",badPasswordMessage:"Μη έγκυρος κωδικός πρόσβασης."}));
