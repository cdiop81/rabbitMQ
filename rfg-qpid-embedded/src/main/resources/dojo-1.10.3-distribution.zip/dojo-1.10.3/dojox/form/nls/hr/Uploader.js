//>>built
define("dojox/form/nls/hr/Uploader",({label:"Izaberite datoteke..."}));
