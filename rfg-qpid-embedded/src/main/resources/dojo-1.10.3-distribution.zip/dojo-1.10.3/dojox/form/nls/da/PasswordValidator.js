//>>built
define("dojox/form/nls/da/PasswordValidator",({nomatchMessage:"Kodeordene stemmer ikke overens.",badPasswordMessage:"Ugyldigt kodeord."}));
