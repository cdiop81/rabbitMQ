define(
"dojox/form/nls/pt-pt/CheckedMultiSelect", ({
	invalidMessage: "É necessário seleccionar pelo menos um artigo.",
	multiSelectLabelText: "{num} artigo(s) seleccionado(s)"
})
);
