//>>built
define("dojox/form/RangeSlider",["dojo/_base/kernel","./_RangeSliderMixin","./HorizontalRangeSlider","./VerticalRangeSlider"],function(_1,_2){
_1.deprecated("Call require() for HorizontalRangeSlider / VerticalRangeSlider, explicitly rather than 'dojox.form.RangeSlider' itself","","2.0");
return _2;
});
