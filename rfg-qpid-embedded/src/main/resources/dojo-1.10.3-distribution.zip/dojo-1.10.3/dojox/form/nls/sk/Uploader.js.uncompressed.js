define(
"dojox/form/nls/sk/Uploader", ({
	label: "Vybrať súbory..."
})
);
