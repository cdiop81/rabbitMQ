//>>built
define("dojox/form/nls/pl/PasswordValidator",({nomatchMessage:"Hasła nie są zgodne.",badPasswordMessage:"Niepoprawne hasło."}));
