define(
"dojox/form/nls/zh/PasswordValidator", ({
        nomatchMessage: "密码不匹配。",
	badPasswordMessage: "密码无效。"
})
);
