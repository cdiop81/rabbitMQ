define(
"dojox/form/nls/uk/PasswordValidator", ({
	nomatchMessage: "Паролі не співпадають.",
	badPasswordMessage: "Неправильний пароль."
})
);
