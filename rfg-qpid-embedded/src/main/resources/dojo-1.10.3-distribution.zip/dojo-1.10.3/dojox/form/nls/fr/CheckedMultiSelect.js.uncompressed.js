define(
"dojox/form/nls/fr/CheckedMultiSelect", ({
	invalidMessage: "Au moins un des éléments doit être sélectionné.",
	multiSelectLabelText: "{num} élément(s) sélectionné(s)"
})
);
