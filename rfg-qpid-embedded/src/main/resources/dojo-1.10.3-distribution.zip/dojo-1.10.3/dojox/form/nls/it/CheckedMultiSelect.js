//>>built
define("dojox/form/nls/it/CheckedMultiSelect",({invalidMessage:"È necessario selezionare almeno un elemento.",multiSelectLabelText:"{num} elementi selezionati"}));
