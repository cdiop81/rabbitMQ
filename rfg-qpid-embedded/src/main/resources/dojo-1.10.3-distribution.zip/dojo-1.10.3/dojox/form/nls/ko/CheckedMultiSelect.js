//>>built
define("dojox/form/nls/ko/CheckedMultiSelect",({invalidMessage:"최소한 한 가지 항목을 선택해야 합니다.",multiSelectLabelText:"{num} 항목이 선택되었습니다."}));
