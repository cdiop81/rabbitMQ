//>>built
define("dojox/form/nls/de/CheckedMultiSelect",({invalidMessage:"Es muss mindestens ein Eintrag ausgewählt werden.",multiSelectLabelText:"{num} Eintrag/Einträge ausgewählt"}));
