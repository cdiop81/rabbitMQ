//>>built
define("dojox/form/_FormSelectWidget",["dojo/_base/kernel","dojo/_base/lang","dijit/form/_FormSelectWidget"],function(_1,_2,_3){
_1.deprecated("dojox.form._FormSelectWidget","Use dijit.form._FormSelectWidget instead","2.0");
_2.setObject("dojox.form._FormSelectWidget",_3);
return _3;
});
