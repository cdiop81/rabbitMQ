define(
"dojox/form/nls/zh-tw/Uploader", ({
	label: "選取檔案..."
})
);
