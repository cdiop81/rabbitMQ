define(
"dojox/form/nls/th/PasswordValidator", ({
        nomatchMessage: "รหัสผ่านไม่ตรงกัน",
	badPasswordMessage: "รหัสผ่านไม่ถูกต้อง"
})
);
