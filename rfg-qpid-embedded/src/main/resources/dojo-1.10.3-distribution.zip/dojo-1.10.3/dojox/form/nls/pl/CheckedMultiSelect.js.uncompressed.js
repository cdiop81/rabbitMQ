define(
"dojox/form/nls/pl/CheckedMultiSelect", ({
	invalidMessage: "Należy wybrać co najmniej jeden element.",
	multiSelectLabelText: "Wybrano elementów: {num}"
})
);
