//>>built
define("dojox/form/nls/ja/Uploader",({label:"ファイルの選択..."}));
