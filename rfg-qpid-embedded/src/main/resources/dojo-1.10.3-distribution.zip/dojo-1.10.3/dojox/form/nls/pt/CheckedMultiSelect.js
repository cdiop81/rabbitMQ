//>>built
define("dojox/form/nls/pt/CheckedMultiSelect",({invalidMessage:"Ao menos um item deve ser selecionado.",multiSelectLabelText:"{num} item(ns) selecionado(s)"}));
