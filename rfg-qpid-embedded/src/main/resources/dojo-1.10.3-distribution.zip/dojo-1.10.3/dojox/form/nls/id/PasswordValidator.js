//>>built
define("dojox/form/nls/id/PasswordValidator",({nomatchMessage:"Kata Kunci tidak sesuai.",badPasswordMessage:"Kata Kunci tidak valid."}));
