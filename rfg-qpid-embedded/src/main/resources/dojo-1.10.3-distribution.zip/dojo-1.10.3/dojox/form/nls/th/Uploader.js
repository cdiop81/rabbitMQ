//>>built
define("dojox/form/nls/th/Uploader",({label:"เลือกไฟล์..."}));
