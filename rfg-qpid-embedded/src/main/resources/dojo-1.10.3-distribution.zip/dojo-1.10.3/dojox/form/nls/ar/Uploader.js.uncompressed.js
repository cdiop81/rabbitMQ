define(
"dojox/form/nls/ar/Uploader", ({
	label: "تحديد ملفات..."
})
);
