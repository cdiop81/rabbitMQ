define("dojox/form/uploader/plugins/IFrame", [],function(){
	console.warn('dojox.form.uploader.plugins.IFrame has been removed. You can use Uploader directly and it will contain all necessary functionality.');
	return {};
});