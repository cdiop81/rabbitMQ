//>>built
define("dojox/dtl/contrib/objects",["dojo/_base/lang","../_base"],function(_1,dd){
var _2=_1.getObject("contrib.objects",true,dd);
_1.mixin(_2,{key:function(_3,_4){
return _3[_4];
}});
dd.register.filters("dojox.dtl.contrib",{"objects":["key"]});
return _2;
});
