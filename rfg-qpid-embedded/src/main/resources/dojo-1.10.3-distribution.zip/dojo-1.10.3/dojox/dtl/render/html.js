//>>built
define("dojox/dtl/render/html",["dojo/_base/lang","../render/dom","../_base"],function(_1,_2,dd){
var _3=_1.getObject("render.html",true,dd);
_3.Render=_2.Render;
return _3;
});
